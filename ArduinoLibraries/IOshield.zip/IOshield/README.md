Crystal IO
========

Library for easy interfacing with MCP23017 or With amazing Crystal IO Shield.

Forked from http://docs.macetech.com/doku.php/centipede_shield
